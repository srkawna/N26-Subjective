({
	getData : function(component) {
        
        var action = component.get("c.getProductData");
        action.setParams({
            caseId: component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            var error = null;
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
            	var initialData = response.getReturnValue();
                component.set('v.priceBookData' ,initialData.pricebookEntryList);
                component.set('v.fieldSetData' ,initialData.fieldsetList);
                
            }else if (state === "ERROR") {
                if(response.getError()[0].message != null){
                    error = response.getError()[0].message;
                } else if(response.getError()[0].pageErrors.length > 0){
                    error = response.getError()[0].pageErrors[0].message;
                } else{
                    error = response.getError()[0].fieldErrors.pageErrors[0].message;
                }
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Failure!",
                    "message": error
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
	}
})